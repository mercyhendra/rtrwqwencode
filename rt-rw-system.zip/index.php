<?php
/**
 * Landing Page (Index)
 * VILLA BINTARO REGENCY RT/RW Digital
 */

require_once __DIR__ . '/includes/auth.php';

// Redirect to dashboard if already logged in
if (isLoggedIn()) {
    $user = getCurrentUser();
    if ($user['role'] === ROLE_WARGA) {
        redirect('warga-saya.php');
    } else {
        redirect('dashboard.php');
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VILLA BINTARO REGENCY RT/RW Digital - Sistem Informasi Manajemen RT/RW</title>
    <link rel="stylesheet" href="css/style-premium.css">
</head>
<body class="landing-page">
    <!-- Navbar -->
    <nav class="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-brand">
                <div class="navbar-brand-icon">🏘️</div>
                <span>VILLA BINTARO<br><span style="font-size: 0.7em; font-weight: 500;">REGENCY</span></span>
            </a>
            <div class="navbar-menu">
                <a href="login.php" class="btn btn-ghost">Login</a>
                <a href="register.php" class="btn btn-primary">Register</a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <div class="hero-icon">🏘️</div>
            <h1 style="font-family: 'Playfair Display', serif;">SELAMAT DATANG DI</h1>
            <h2 style="font-size: 2rem; font-weight: 700; margin-bottom: var(--space-4);">VILLA BINTARO REGENCY RT/RW</h2>
            <p>Sistem Informasi Manajemen RT/RW Digital untuk lingkungan yang lebih modern, transparan, dan efisien</p>
            <div class="hero-buttons">
                <a href="login.php" class="btn btn-primary btn-lg">Masuk Aplikasi</a>
                <a href="register.php" class="btn btn-outline btn-lg">Daftar Sekarang</a>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features">
        <div class="features-header">
            <h2 style="font-family: 'Playfair Display', serif;">Fitur Unggulan</h2>
            <p>Kelola lingkungan RT/RW Anda dengan lebih mudah dan efisien</p>
        </div>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">👥</div>
                <h3>Data Warga</h3>
                <p>Kelola data warga dengan lengkap dan terorganisir dalam satu sistem terpusat</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📢</div>
                <h3>Pengumuman</h3>
                <p>Sampaikan informasi penting kepada seluruh warga dengan mudah dan cepat</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📋</div>
                <h3>Surat Keterangan</h3>
                <p>Urus surat keterangan domisili dan administrasi lainnya secara online</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">💰</div>
                <h3>Iuran Warga</h3>
                <p>Pantau dan kelola iuran warga dengan transparan dan akuntabel</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📅</div>
                <h3>Kegiatan</h3>
                <p>Jadwalkan dan kelola kegiatan lingkungan seperti kerja bakti dan rapat</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🔔</div>
                <h3>Notifikasi</h3>
                <p>Dapatkan notifikasi real-time untuk informasi penting dan mendesak</p>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats">
        <div class="stats-container">
            <div class="stat-item">
                <h3>150+</h3>
                <p>Kepala Keluarga</p>
            </div>
            <div class="stat-item">
                <h3>500+</h3>
                <p>Total Warga</p>
            </div>
            <div class="stat-item">
                <h3>50+</h3>
                <p>Kegiatan/Tahun</p>
            </div>
            <div class="stat-item">
                <h3>100%</h3>
                <p>Transparan</p>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content" style="text-align: center;">
            <p><strong style="color: white; font-size: 1.125rem;">Villa Bintaro Regency RT/RW Digital</strong></p>
            <p style="color: var(--slate-400);">Sistem Informasi Manajemen RT/RW untuk lingkungan yang lebih baik</p>
            <div class="footer-links">
                <a href="#">Tentang Kami</a>
                <a href="#">Kontak</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Service</a>
            </div>
            <p style="color: var(--slate-500); font-size: 0.875rem;">&copy; 2025 VILLA BINTARO REGENCY RT/RW Digital. All rights reserved. <span style="color: var(--slate-600); font-size: 0.8125rem; margin-left: var(--space-2);">| By Mercy Hendra</span></p>
        </div>
    </footer>

    <script src="js/main.js"></script>
</body>
</html>
