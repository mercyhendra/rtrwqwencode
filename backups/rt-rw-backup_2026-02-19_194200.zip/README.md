# VILLA BINTARO REGENCY RT/RW Digital Management System

Sistem Informasi Manajemen RT/RW Digital untuk pengelolaan lingkungan yang lebih efisien dan transparan.

## 📋 Fitur Utama

### Untuk Admin/RT/RW
- ✅ **Dashboard** - Statistik dan ringkasan data
- ✅ **Data Warga** - CRUD lengkap data warga
- ✅ **Kartu Keluarga** - Manajemen KK (1 KK per keluarga)
- ✅ **Pengumuman** - Buat dan kelola pengumuman
- ✅ **Notifikasi** - Sistem notifikasi real-time
- ✅ **Layanan Surat** - Kelola permohonan surat
- ✅ **Kas & Iuran** - Tracking iuran warga
- ✅ **Kegiatan** - Manajemen kegiatan lingkungan
- ✅ **Laporan** - Generate berbagai laporan

### Untuk Warga
- ✅ **Data Saya** - Lihat data pribadi sendiri
- ✅ **Keluarga Saya** - Lihat data keluarga
- ✅ **Iuran Saya** - Cek status iuran pribadi
- ✅ **Layanan Surat** - Ajukan surat online
- ✅ **Pengumuman** - Lihat pengumuman RT/RW

## 🔐 Sistem Role (Hak Akses)

| Role | Akses Data Warga | Edit/Hapus |
|------|-----------------|------------|
| **Admin** | Semua data | ✅ Semua data |
| **RT** | Semua data | ✅ Semua data |
| **RW** | Semua data | ✅ Semua data |
| **Warga** | ❌ Hanya data sendiri | ❌ Tidak bisa |

## 🚀 Cara Menjalankan

1. Buka file `index.html` di browser
2. Untuk akses sistem, login dengan kredensial di bawah

## 👤 Akun Demo

### Admin
- **Email:** `admin@rtrw.com`
- **Password:** `admin123`
- **Akses:** Full (Dashboard Admin)

### Ketua RT
- **Email:** `rt@rtrw.com`
- **Password:** `rt123`
- **Akses:** Full (Dashboard Admin)

### Warga
- **Email:** `warga@rtrw.com`
- **Password:** `warga123`
- **Akses:** Terbatas (Data sendiri saja)

## 📁 Struktur File

```
rt-rw-system/
├── index.html              # Landing page
├── login.html              # Login page
├── register.html           # Register page
├── dashboard.html          # Dashboard admin
├── warga.html              # Data warga (admin only)
├── kk.html                 # Kartu keluarga (admin only)
├── pengumuman.html         # Pengumuman
├── notifikasi.html         # Notifikasi
├── layanan.html            # Layanan surat
├── iuran.html              # Kas & iuran (admin only)
├── kegiatan.html           # Kegiatan
├── laporan.html            # Laporan (admin only)
├── warga-saya.html         # Data saya (warga)
├── keluarga-saya.html      # Keluarga saya (warga)
├── iuran-saya.html         # Iuran saya (warga)
├── css/
│   └── style.css           # Main stylesheet
└── js/
    ├── auth.js             # Authentication & Authorization
    └── main.js             # Main JavaScript
```

## 🔧 Fitur Keamanan

1. **Role-Based Access Control (RBAC)**
   - Setiap user memiliki role (Admin, RT, RW, Warga)
   - Akses data dibatasi berdasarkan role

2. **Session Management**
   - Login session disimpan di localStorage
   - Auto redirect berdasarkan role

3. **Data Privacy**
   - Warga hanya bisa lihat data sendiri
   - Admin/RT/RW bisa lihat semua data

4. **Validasi Form**
   - NIK harus 16 digit
   - KK harus 16 digit (unik per keluarga)
   - Password minimal 8 karakter

## 💾 Penyimpanan Data

Sistem ini menggunakan **localStorage** browser untuk demo. Untuk production, disarankan menggunakan:

- **Backend:** Node.js, PHP, Python, dll.
- **Database:** MySQL, PostgreSQL, MongoDB
- **Authentication:** JWT, OAuth, dll.

## 🎨 Teknologi

- HTML5
- CSS3 (Custom CSS dengan CSS Variables)
- JavaScript (Vanilla JS)
- LocalStorage (untuk demo)

## 📝 Catatan Penting

1. **1 KK per Keluarga:** Setiap nomor KK hanya bisa terdaftar sekali
2. **WhatsApp Field:** Ditambahkan untuk notifikasi penting
3. **Role Default:** User baru yang register otomatis mendapat role "Warga"
4. **Data Demo:** Sudah tersedia 3 user default (Admin, RT, Warga)

## 🔄 Reset Data

Untuk reset semua data ke default:
```javascript
localStorage.clear();
location.reload();
```

## 📞 Support

Untuk pertanyaan atau bantuan, hubungi administrator sistem.

---

**© 2025 VILLA BINTARO REGENCY RT/RW Digital Management System**
