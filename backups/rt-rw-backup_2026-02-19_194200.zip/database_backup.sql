-- ========================================
-- Database Backup: wargavbr
-- Date: 2026-02-19 19:42:00
-- ========================================

-- Table: anggota_keluarga
DROP TABLE IF EXISTS `anggota_keluarga`;
CREATE TABLE `anggota_keluarga` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nik` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hubungan` enum('kepala_keluarga','istri','suami','anak','lainnya') COLLATE utf8mb4_unicode_ci DEFAULT 'lainnya',
  `jenis_kelamin` enum('L','P') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempat_lahir` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `pekerjaan` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_perkawinan` enum('belum_kawin','kawin','cerai_hidup','cerai_mati') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nik` (`nik`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `anggota_keluarga_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: anggota_keluarga_request
DROP TABLE IF EXISTS `anggota_keluarga_request`;
CREATE TABLE `anggota_keluarga_request` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `no_kk` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_lengkap` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nik` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hubungan` enum('istri','suami','anak','orang_tua','saudara','lainnya') COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_kelamin` enum('L','P') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempat_lahir` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `pekerjaan` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_perkawinan` enum('belum_kawin','kawin','cerai_hidup','cerai_mati') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alasan` text COLLATE utf8mb4_unicode_ci,
  `dokumen_pendukung` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `catatan_admin` text COLLATE utf8mb4_unicode_ci,
  `dibuat_oleh` int DEFAULT NULL,
  `disetujui_oleh` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `dibuat_oleh` (`dibuat_oleh`),
  KEY `disetujui_oleh` (`disetujui_oleh`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_no_kk` (`no_kk`),
  KEY `idx_status` (`status`),
  CONSTRAINT `anggota_keluarga_request_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `anggota_keluarga_request_ibfk_2` FOREIGN KEY (`dibuat_oleh`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `anggota_keluarga_request_ibfk_3` FOREIGN KEY (`disetujui_oleh`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: iuran
DROP TABLE IF EXISTS `iuran`;
CREATE TABLE `iuran` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `jenis_iuran` enum('kebersihan','keamanan','sampah','lainnya') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nominal` decimal(10,2) NOT NULL,
  `bulan` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_bayar` datetime DEFAULT NULL,
  `status` enum('belum_bayar','lunas') COLLATE utf8mb4_unicode_ci DEFAULT 'belum_bayar',
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `dibuat_oleh` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `dibuat_oleh` (`dibuat_oleh`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_bulan` (`bulan`),
  KEY `idx_status` (`status`),
  CONSTRAINT `iuran_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `iuran_ibfk_2` FOREIGN KEY (`dibuat_oleh`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: kegiatan
DROP TABLE IF EXISTS `kegiatan`;
CREATE TABLE `kegiatan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_kegiatan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` enum('umum','kesehatan','sosial','olahraga','keagamaan','pengurus') COLLATE utf8mb4_unicode_ci DEFAULT 'umum',
  `tanggal_kegiatan` datetime NOT NULL,
  `lokasi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `kuota_peserta` int DEFAULT NULL,
  `jumlah_peserta` int DEFAULT '0',
  `status` enum('aktif','selesai','batal') COLLATE utf8mb4_unicode_ci DEFAULT 'aktif',
  `dibuat_oleh` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `dibuat_oleh` (`dibuat_oleh`),
  KEY `idx_kategori` (`kategori`),
  KEY `idx_status` (`status`),
  CONSTRAINT `kegiatan_ibfk_1` FOREIGN KEY (`dibuat_oleh`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: layanan_surat
DROP TABLE IF EXISTS `layanan_surat`;
CREATE TABLE `layanan_surat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `jenis_surat` enum('domisili','ktp','kelahiran','kematian','nikah','usaha') COLLATE utf8mb4_unicode_ci NOT NULL,
  `keperluan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','proses','selesai','ditolak') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `no_surat` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan_admin` text COLLATE utf8mb4_unicode_ci,
  `dibuat_oleh` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `dibuat_oleh` (`dibuat_oleh`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `layanan_surat_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `layanan_surat_ibfk_2` FOREIGN KEY (`dibuat_oleh`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: notifikasi
DROP TABLE IF EXISTS `notifikasi`;
CREATE TABLE `notifikasi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipe` enum('info','warning','success','danger') COLLATE utf8mb4_unicode_ci DEFAULT 'info',
  `sudah_dibaca` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_sudah_dibaca` (`sudah_dibaca`),
  CONSTRAINT `notifikasi_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: pengumuman
DROP TABLE IF EXISTS `pengumuman`;
CREATE TABLE `pengumuman` (
  `id` int NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` enum('umum','penting','warga','darurat') COLLATE utf8mb4_unicode_ci DEFAULT 'umum',
  `tanggal_acara` datetime DEFAULT NULL,
  `lokasi_acara` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dibuat_oleh` int NOT NULL,
  `views` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `dibuat_oleh` (`dibuat_oleh`),
  KEY `idx_kategori` (`kategori`),
  CONSTRAINT `pengumuman_ibfk_1` FOREIGN KEY (`dibuat_oleh`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','rt','rw','warga') COLLATE utf8mb4_unicode_ci DEFAULT 'warga',
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nik` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_kk` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rt` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rw` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_rumah` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pekerjaan` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('aktif','pindah','meninggal') COLLATE utf8mb4_unicode_ci DEFAULT 'aktif',
  `status_keluarga` enum('kepala_keluarga','anggota') COLLATE utf8mb4_unicode_ci DEFAULT 'anggota',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `nik` (`nik`),
  KEY `idx_email` (`email`),
  KEY `idx_nik` (`nik`),
  KEY `idx_no_kk` (`no_kk`),
  KEY `idx_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `uuid`, `email`, `password`, `role`, `nama`, `nik`, `no_kk`, `rt`, `rw`, `no_rumah`, `whatsapp`, `pekerjaan`, `status`, `status_keluarga`, `created_at`, `updated_at`) VALUES ('1', '2d906c09-0d9d-11f1-94f7-00e04c6860b7', 'admin@rtrw.com', '$2y$10$AvAjDbKK870syfBZ5FnqZuMbDvF4bg1RHBM1x8ywobGx.76FGHPSS', 'admin', 'Administrator', '3171012345678999', '3171012345678999', '001', '001', 'A-01', '081234567890', 'Administrator Sistem', 'aktif', 'anggota', '2026-02-19 21:13:34', '2026-02-19 21:27:52');
INSERT INTO `users` (`id`, `uuid`, `email`, `password`, `role`, `nama`, `nik`, `no_kk`, `rt`, `rw`, `no_rumah`, `whatsapp`, `pekerjaan`, `status`, `status_keluarga`, `created_at`, `updated_at`) VALUES ('2', '2d94f2cd-0d9d-11f1-94f7-00e04c6860b7', 'rt@rtrw.com', '$2y$10$OQ3u2h30j9RHt0xBq0cDM.c1i2NcKWU7ZAbBzhz4qlm63Ys4KIpA2', 'rt', 'Ketua RT 001', '3171012345678998', '3171012345678998', '001', '001', 'A-02', '081234567891', 'Ketua RT', 'aktif', 'anggota', '2026-02-19 21:13:34', '2026-02-19 21:27:52');
INSERT INTO `users` (`id`, `uuid`, `email`, `password`, `role`, `nama`, `nik`, `no_kk`, `rt`, `rw`, `no_rumah`, `whatsapp`, `pekerjaan`, `status`, `status_keluarga`, `created_at`, `updated_at`) VALUES ('3', '2d94fda8-0d9d-11f1-94f7-00e04c6860b7', 'warga@rtrw.com', '$2y$10$I.Z7C4wSNppGfzXGdBljhuDgViC.Sj8fHhMN3JV3ONTIQeONDAXUe', 'warga', 'Ahmad Santoso', '3171012345678901', '3171012345678001', '001', '001', 'A-12', '081234567890', 'Wiraswasta', 'aktif', 'kepala_keluarga', '2026-02-19 21:13:34', '2026-02-20 02:27:06');
INSERT INTO `users` (`id`, `uuid`, `email`, `password`, `role`, `nama`, `nik`, `no_kk`, `rt`, `rw`, `no_rumah`, `whatsapp`, `pekerjaan`, `status`, `status_keluarga`, `created_at`, `updated_at`) VALUES ('4', '921e57d5-22ac-4677-ad39-03a66bc95378', 'nanda@local', '$2y$10$Ap3qc3wsGkv6V1qaxrqHz.TIPFQEBOFI9WBVV5IESV3IUIhjpNDP6', 'warga', 'nanda', '3171012345678003', '3171012345678002', '001/001', '001', 'F3', '081288492321', 'it', 'aktif', 'kepala_keluarga', '2026-02-19 22:52:44', '2026-02-20 02:27:06');
INSERT INTO `users` (`id`, `uuid`, `email`, `password`, `role`, `nama`, `nik`, `no_kk`, `rt`, `rw`, `no_rumah`, `whatsapp`, `pekerjaan`, `status`, `status_keluarga`, `created_at`, `updated_at`) VALUES ('5', '57e8e24a-b213-494f-a63e-5fb1b86413aa', 'testapi88@example.com', '$2y$10$D0YbGYrH5Ei6gwCqAqZ4guunAjbje9zKVt1Vu82UuyVtX7YPItIe2', 'warga', 'Test API User', '3171012345678887', '3171012345678888', '001', '001', 'A-88', '081234567888', 'API Tester', 'aktif', 'kepala_keluarga', '2026-02-19 23:13:16', '2026-02-20 02:27:06');
INSERT INTO `users` (`id`, `uuid`, `email`, `password`, `role`, `nama`, `nik`, `no_kk`, `rt`, `rw`, `no_rumah`, `whatsapp`, `pekerjaan`, `status`, `status_keluarga`, `created_at`, `updated_at`) VALUES ('7', '3a757392-3623-43ac-aa51-ed35418419cc', 'gendon@temp.local', '$2y$10$cmTonr71lUnZszmcMl0ZJOnrXVHSqxRGz2xgP7ALRrK7.00C5nmJu', 'warga', 'Gendon', '1231451234567895', '3171012345678002', '001/001', '001', 'F3', '081288492321', 'it', 'aktif', 'anggota', '2026-02-20 01:40:05', '2026-02-20 01:40:05');
INSERT INTO `users` (`id`, `uuid`, `email`, `password`, `role`, `nama`, `nik`, `no_kk`, `rt`, `rw`, `no_rumah`, `whatsapp`, `pekerjaan`, `status`, `status_keluarga`, `created_at`, `updated_at`) VALUES ('8', '9a15d29b-3461-48fd-aac1-d12a541800df', 'siti nurhaliza@temp.local', '$2y$10$w5TVXIEZBHAzCS80MTiYvOKqcBtnYYjcLQ0k6fgg6Y4/6CNCvaxIq', 'warga', 'Siti Nurhaliza', '3171012345678902', '3171012345678001', '001', '001', 'A-12', '081234567890', 'Ibu Rumah Tangga', 'aktif', 'anggota', '2026-02-20 02:09:40', '2026-02-20 02:09:40');

